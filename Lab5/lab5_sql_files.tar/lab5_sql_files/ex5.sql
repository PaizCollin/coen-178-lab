Create or Replace Procedure setEmpSalary(p_name in VARCHAR, low in INTEGER, high in INTEGER)
As
	/* Define the local variables you need */

	
BEGIN
	/* since name is a primary key, set the salary 
	Of the employee where name = p_name. 
	
	With an update statement, set the salary of that employee
	With a randomly generated value between the low and high passed 
	In as parameters
	*/

		
END;
/
show errors;

